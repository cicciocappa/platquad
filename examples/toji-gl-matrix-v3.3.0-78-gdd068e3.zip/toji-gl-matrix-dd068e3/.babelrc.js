export default {
  "presets": [["@babel/env", { "modules": false }]]
};
